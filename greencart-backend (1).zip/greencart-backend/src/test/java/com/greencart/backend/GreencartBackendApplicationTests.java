package com.greencart.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreencartBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
